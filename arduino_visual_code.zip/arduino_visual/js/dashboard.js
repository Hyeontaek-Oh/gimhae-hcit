// 아두이노 장치에 작성한 serviceID와 같은 ID를 사용해야함
const serviceUuid = "19b10010-e8f2-537e-4f6c-d104768a1214";

let gyroscopeCharacteristic;
let gx = 0, gy = 0, gz = 0;
let myBLE;

function setup() {
  // Create a p5ble class
  myBLE = new p5ble();
}

function connectAndStartNotify() {
  // Connect to a device by passing the service UUID
  myBLE.connect(serviceUuid, gotCharacteristics);
}

// A function that will be called once got characteristics
function gotCharacteristics(error, characteristics) {
  if (error) console.log('error: ', error);
  else {
    console.log( characteristics.length)
    for (let i = 0; i < characteristics.length; i++) {
      switch (i) {
        case 0:
          gyroscopeCharacteristic = characteristics[i];
          myBLE.startNotifications(gyroscopeCharacteristic, handleGyroscope, 'custom');
          break;
        default:
          console.log("characteristic doesn't match.");
      }
    }
  }
}

function cutFixed(val, point) {
  return Math.round(val*Math.pow(10,point))/Math.pow(10,point);
}


let gxs = [], gys = [], gzs = [];
let index = [];
let time = 0;
function handleGyroscope(data) {
  gx = cutFixed(data.getFloat32(0, true), 2);
  gy = cutFixed(data.getFloat32(4, true), 2);
  gz = cutFixed(data.getFloat32(8, true), 2);
  gxs.push(gx);
  gys.push(gy);
  gzs.push(gz);
  index.push(time++);
  
  let myChart = echarts.init(document.getElementById('myChart'));
  // specify chart configuration item and data
  console.log(gx,gy,gz);
  var options = {
      title: {
          text: 'Gyro Value'
      },
      animation: false,
      tooltip: {
          trigger: 'axis'
      },
      legend: {
          data: ['gx', 'gy', 'gz']
      },
      grid: {
          left: '3%', right: '4%',
          bottom: '3%',
          containLabel: true
      },

      xAxis: {
          type: 'category', boundaryGap: false, data: time
      },
      yAxis: {
          type: 'value',
      },
      series: [
      {
          name: 'gx', type: 'line', data: gxs
      },
      {
          name: 'gy', type: 'line', data: gys
      },
      {
          name: 'gz', type: 'line', data: gzs
      },
      ]
  };
  myChart.setOption(options);
}