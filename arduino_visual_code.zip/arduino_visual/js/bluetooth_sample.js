// The serviceUuid must match the serviceUuid of the device you would like to connect
const serviceUuid = "19b10010-e8f2-537e-4f6c-d104768a1214";
let gyroscopeCharacteristic;
let gx = 0, gy = 0, gz = 0;
let myBLE;
let input;

function setup() {
  // Create a p5ble class
  myBLE = new p5ble();

  createCanvas(1000, 600);
  background("#FFF");
  textSize(14);

  // 화면에 보일 버튼을 하나 생성
  const connectButton = createButton('Connect and Start Notifications');
  connectButton.mousePressed(connectAndStartNotify);
  connectButton.position(100, 550)
}

function connectAndStartNotify() {
  // Connect to a device by passing the service UUID
  myBLE.connect(serviceUuid, gotCharacteristics);
}

// A function that will be called once got characteristics
function gotCharacteristics(error, characteristics) {
  if (error) console.log('error: ', error);
  else {
    console.log( characteristics.length)
    for (let i = 0; i < characteristics.length; i++) {
      switch (i) {
        case 0:
          gyroscopeCharacteristic = characteristics[i];
          myBLE.startNotifications(gyroscopeCharacteristic, handleGyroscope, 'custom');
          console.log(i);
          break;
        default:
          console.log("characteristic doesn't match.");
      }
    }
  }
}

function cutFixed(val, point) {
  return Math.round(val*Math.pow(10,point))/Math.pow(10,point);
}

function handleGyroscope(data) {
  t = new Date().getTime()
  gx = cutFixed(data.getFloat32(0, true), 2);
  gy = cutFixed(data.getFloat32(4, true), 2);
  gz = cutFixed(data.getFloat32(8, true), 2);
}

function draw() {
  background(255);

  text(`Gyroscope X: `+gx, 50, 50);
  text(`Gyroscope Y: `+gy, 50, 100);
  text(`Gyroscope Z: `+gz, 50, 150);
}
