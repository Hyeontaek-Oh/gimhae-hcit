//모듈 불러오기
var express = require('express')
var path = require('path')
var https = require('https')
var fs = require('fs')

// SSL key read
var pk = fs.readFileSync('private.pem','utf8')
var cert = fs.readFileSync('public.pem','utf8')
var credentials = {key: pk, cert: cert}

 //익스프레스 객체 생성
var app=express()

app.use('/css',express.static(__dirname+'/css'))
app.use('/js',express.static(__dirname+'/js'))

// 루트 경로(/) 파일을 내보낸다.
app.get('/',function(request,response){
	response.sendFile(path.join(__dirname+'/bluetooth_sample.html'))
})
app.get('/dashboard.html', function (request, response) {
  response.sendFile(path.join(__dirname + '/dashboard.html'));
})
// set https server
//
var httpsServer = https.createServer(credentials, app)

httpsServer.listen(8443)
console.log("포트번호 8443번에서 서버가 실행되었습니다.")