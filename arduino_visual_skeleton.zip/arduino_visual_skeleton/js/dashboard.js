// 아두이노 장치에 작성한 serviceID와 같은 ID를 사용해야함
// ID 작성
const serviceUuid = "";

let gyroscopeCharacteristic;
let myBLE;

function setup() {
  // Create a p5ble class
  myBLE = new p5ble();
}

function connectAndStartNotify() {
  // Connect to a device by passing the service UUID
  myBLE.connect(serviceUuid, gotCharacteristics);
}

// A function that will be called once got characteristics
function gotCharacteristics(error, characteristics) {
  if (error) console.log('error: ', error);
  else {
    console.log( characteristics.length)
    for (let i = 0; i < characteristics.length; i++) {
      switch (i) {
        case 0:
          gyroscopeCharacteristic = characteristics[i];
          myBLE.startNotifications(gyroscopeCharacteristic, handleGyroscope, 'custom');
          break;
        default:
          console.log("characteristic doesn't match.");
      }
    }
  }
}

function cutFixed(val, point) {
  return Math.round(val*Math.pow(10,point))/Math.pow(10,point);
}

// 그래프 출력을 위한 데이터 배열 정의
let gxs = [], gys = [], gzs = [];
let index = [];
let time = 0;

// 세부 작성
// 자이로 센서 값 처리 함수
function handleGyroscope(data) {

}