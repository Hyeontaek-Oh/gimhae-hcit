// 아두이노 장치에 작성한 serviceID와 같은 ID를 사용해야함
const serviceUuid = "19B10010-E8F2-537E-4F6C-D104778A1214";

let gyroscopeCharacteristic;
let gx = 0, gy = 0, gz = 0;
let myBLE;

function setup() {
  // Create a p5ble class
  myBLE = new p5ble();
}

function connectAndStartNotify() {
  // Connect to a device by passing the service UUID
  myBLE.connect(serviceUuid, gotCharacteristics);
}

// A function that will be called once got characteristics
function gotCharacteristics(error, characteristics) {
  if (error) console.log('error: ', error);
  else {
    console.log( characteristics.length)
    for (let i = 0; i < characteristics.length; i++) {
      switch (i) {
        case 0:
          gyroscopeCharacteristic = characteristics[i];
          myBLE.startNotifications(gyroscopeCharacteristic, handleGyroscope, 'custom');
          break;
        default:
          console.log("characteristic doesn't match.");
      }
    }
  }
}

function cutFixed(val, point) {
  return Math.round(val*Math.pow(10,point))/Math.pow(10,point);
}

// 그래프 출력을 위한 데이터 배열 정의
let gxs = [], gys = [], gzs = [];
let index = [];
let time = 0;

// 자이로 센서 값 처리 함수
function handleGyroscope(data) {
  gx = cutFixed(data.getFloat32(0, true), 2);
  gy = cutFixed(data.getFloat32(4, true), 2);
  gz = cutFixed(data.getFloat32(8, true), 2);
  
  // 데이터를 계속 누적으로 배열에 저장함
  gxs.push(gx);
  gys.push(gy);
  gzs.push(gz);
  index.push(time++);
  
  // 차트 그리는 부분 (작성 필요)
  let myChart = echarts.init(document.getElementById('myChart'));
  // 작성
}